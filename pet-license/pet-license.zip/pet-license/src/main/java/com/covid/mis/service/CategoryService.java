package com.covid.mis.service;

import java.util.List;

import com.covid.mis.bean.CategoryBean;

public interface CategoryService {

	List<CategoryBean> getCategory();
	
}
