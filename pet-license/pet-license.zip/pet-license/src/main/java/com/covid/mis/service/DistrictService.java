package com.covid.mis.service;

import java.util.List;

import com.covid.mis.bean.DistrictBean;

public interface DistrictService {

	public List<DistrictBean> getDistrict();
}
