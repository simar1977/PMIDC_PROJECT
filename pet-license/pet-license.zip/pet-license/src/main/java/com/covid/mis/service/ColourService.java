package com.covid.mis.service;

import java.util.List;

import com.covid.mis.bean.ColourBean;

public interface ColourService {

	List<ColourBean> getColour();
	
}
