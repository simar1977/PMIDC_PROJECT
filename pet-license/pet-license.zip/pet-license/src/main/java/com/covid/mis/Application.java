package com.covid.mis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.springframework.boot.context.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.context.annotation.Bean;

import com.ccavenue.security.AesCryptUtil;

@SpringBootApplication
public class Application extends SpringBootServletInitializer{
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		String result=null;
		String err=null;
		String key = null;
		String data = null;
		String action = null;

		if(args==null || args.length<3) 
			err="error: missing one or more arguments. Usage: AesCryptUtil key data <enc|dec>";
		else {
			key = args[0];
			data = args[1];
			action = args[2];

			if(key==null)
				err="error: no key";
			else
			if(key.length()<32)
				err="error: key length less than 32 bytes";
			else
			if(data==null || action==null)
				err="error: no data";
			else
			if(action==null)
				err="error: no action";
			else
			if(!action.equals("enc") && !action.equals("dec"))
				err="error: invalid action";
		}

		if(err==null) {
			try {
				AesCryptUtil encrypter = new AesCryptUtil(key);

				if(action.equals("enc"))
					result = encrypter.encrypt(data);
				else
					result = encrypter.decrypt(data);
			}
			catch (Exception e) {
				err="error : Exception in performing the requested operation : " + e;
			}
		}
		if(result!=null)
			System.out.println(result);
		else
			System.out.println(err);
	}

	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		
        return builder.sources(Application.class);
    }
	
	@Bean
    public TomcatEmbeddedServletContainerFactory tomcatEmbedded() {

        TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory();

        tomcat.addConnectorCustomizers((TomcatConnectorCustomizer) connector -> {
            if ((connector.getProtocolHandler() instanceof AbstractHttp11Protocol<?>)) {
                //-1 means unlimited
                ((AbstractHttp11Protocol<?>) connector.getProtocolHandler()).setMaxSwallowSize(-1);
            }
        });

        return tomcat;

    }
}
