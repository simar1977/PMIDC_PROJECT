package com.covid.mis.util;

public class ErrorConstant {

}
